package com.example.parcial3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText cuota;
    Spinner cum1;
    Spinner carrera1;
    Spinner institucion1;
    TextView CL;
    TextView DI;
    TextView DC;
    TextView CCAR;
    TextView TLP;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DC = findViewById(R.id.descuentoCu);
        TLP = findViewById(R.id.total);
        CCAR = findViewById(R.id.costoCarr);
        cum1 = findViewById(R.id.cum);
        DI = findViewById(R.id.descuentoinst);
        CL = findViewById(R.id.costoLab);
        cuota = findViewById(R.id.costoc);
        carrera1 = findViewById(R.id.carrera);
        institucion1 = findViewById(R.id.institucion);
    }
    public void Calculo(View view){
        String Select;
        double IngMdBD = 20;
        double IngSis = 25;
        double TecSis = 30;
        String S;
        double priv = 0.10;
        double pub = 0.05;
        double DesIn = 0;
        double clbt = 0;


        Select = carrera1.getSelectedItem().toString();
        double COT = Double.parseDouble(cuota.getText().toString());
        S = institucion1.getSelectedItem().toString();

        if(Select.equals("Ingenieria en Manejo y Gestion de Base de Datos")){
            clbt = IngMdBD;
            CL.setText("$" + IngMdBD);
        }else{
            if(Select.equals("Ingenieria en Sistemas")){
                clbt = IngSis;
                CL.setText("$" + IngSis);
            }else {
                if(Select.equals("Tecnico en SIstemas")){
                    clbt = TecSis;
                    CL.setText("$" + TecSis);
                }
            }
        }
        if(S.equals("Privada")){
            DesIn = (COT*priv);
            DI.setText("$"+(COT*priv));
        }else{
            if(S.equals("Pública")){
                DesIn = (COT*pub);
                DI.setText("$"+(COT*pub));
            }
        }

        String E;
        double Max = 0.25;
        double Medio = 0.20;
        double Minimo = 0.15;
        double Nad = 0;
        double dst = 0;


        E = cum1.getSelectedItem().toString();
        if(E.equals("10")){
            dst = (COT*Max);
            DC.setText("$"+(COT*Max));
        }else{
            if(E.equals("9")){
                dst = (COT*Max);
                DC.setText("$"+(COT*Max));
            }else{
                if(E.equals("8")){
                    dst = (COT*Medio);
                    DC.setText("$"+(COT*Medio));
                }else{
                    if(E.equals("7")){
                        dst = (COT*Minimo);
                        DC.setText("$"+(COT*Minimo));
                    }else{
                        if(E.equals("6")){
                            dst = (COT*Nad);
                            DC.setText("$"+Nad);
                        }
                    }
                }
            }
        }
        String C;
        double IMD = 0.30;
        double IS = 0.40;
        double TS = 0.45;
        double CostCarr = 0;

        C = carrera1.getSelectedItem().toString();
        if(C.equals("Ingenieria en Manejo y Gestion de Base de Datos")){
            CostCarr = (COT*IMD);
            CCAR.setText("$"+(COT*IMD));
        }else{
            if(C.equals("Ingenieria en Sistemas")){
                CostCarr = (COT*IS);
                CCAR.setText("$"+(COT*IS));
            }else{
                if(C.equals("Tecnico en SIstemas")){
                    CostCarr = (COT*TS);
                    CCAR.setText("$"+(COT*TS));
                }
            }
        }
        double aa1 = 0;
        double bb2 = 0;
        double ccp = 0;
        aa1 = (dst+DesIn);
        bb2 = (clbt+CostCarr);
        ccp = (bb2 - aa1);

        TLP.setText("$"+ (COT+ccp));
    }
}